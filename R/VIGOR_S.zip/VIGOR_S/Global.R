library(shinydashboard)  
library(shiny) 
library(dplyr)
library(readxl)
library(writexl)
library(shinyjs)
library(shinyjs)


setwd("C:/Users/USUARIO/Desktop/dev/R/VIGOR_S")

#BASE <- BASE %>% filter(TipoID==0)

load("BASE.Rdata")
