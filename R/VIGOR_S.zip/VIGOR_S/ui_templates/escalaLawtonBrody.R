tabEscalaLawtonBrody <- tabItem(
    "sub1_3", h1(strong("Escala de Lawton Brody"), align = "center"),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "determinar la capacidad de la persona adulta mayor para realizar las actividades instrumentales de la vida diaria que le
                                        permiten vivir de manera independiente en su comunidad.")),
        br(),
        br(),
        radioButtons("LAWTONB_P1", em("1.Capacidad para usar el tel\u00E9fono"),
            choices = list(
                "Utilizar el tel\u00E9fono por iniciativa propia" = 0,
                "Es capaz de buscar y marcar bien algunos n\u00FAmeros familiares " = 1,
                "Es capaz de contestar el tel\u00E9fono, pero no marcar " = 2,
                "No utiliza el tel\u00E9fono" = 3
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        radioButtons("LAWTONB_P2", em("2.Hacer compras"),
            choices = list(
                "Realiza todas las compras de manera independiente" = 0,
                "Realiza de manera independiente peque\u00F1as compras" = 1,
                "Necesita ir acompa\u00F1ado para realizar cualquier compra" = 2,
                "Totalmente incapaz de comprar" = 3
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        radioButtons("LAWTONB_P3", em("3.Preparaci\u00F3n de la comida"),
            choices = list(
                "Organiza, prepara y sirve las comidas adecuadas con independencia" = 0,
                "Prepara adecuadamente las comidas si se le proporcionan los ingredientes" = 1,
                "Prepara, calienta y sirve las comidas, pero no siguen una dieta adecuada" = 2,
                "Necesita que le preparen y sirvan las comidas" = 3
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        radioButtons("LAWTONB_P4", em("4.Cuidado de la casa "),
            choices = list(
                "Mantiene la casa solo con ayuda ocasional (para trabajos pesados)" = 0,
                "Realiza trabajos ligeros como, lavar los platos o hacer la camas" = 1,
                "Realiza tareas ligeras, pero no puede mantener un adecuado nivel de limpieza" = 2,
                "Necesita ayuda en todas las labores de la casa " = 3,
                "No participa en ninguna labor de la casa " = 4
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        radioButtons("LAWTONB_P5", em("5.Lavado de la ropa"),
            choices = list(
                "Lava por si solo toda su ropa" = 0,
                "Lava por si solo peque\u00F1as prendas " = 1,
                "Todo el lavado de ropa debe ser realizado por otro" = 2
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        radioButtons("LAWTONB_P6", em("6.Uso de medios de transporte"),
            choices = list(
                "Viaja solo, en transporte p\u00FAblico o conduce su propio vehiculo" = 0,
                "Es capaz de tomar un taxi, pero no usa otro medio de transporte" = 1,
                "Viaja en trasporte p\u00FAblico cuando va acompa\u00F1ado por otra persona" = 2,
                "Utiliza el taxi o el autom\u00F3vil solo con ayuda de otros " = 3,
                "No viaja en absoluto " = 4
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        radioButtons("LAWTONB_P7", em("7.Responsabilidad respecto a su medicaci\u00F3n"),
            choices = list(
                "Es capaz de tomar su medicaci\u00F3n a la hora y dosis correcta" = 0,
                "Toma su medicaci\u00F3n si la dosis es preparada previamente" = 1,
                "No es capaz de administrarse su medicaci\u00F3n" = 2
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        radioButtons("LAWTONB_P8", em("8. Manejo de sus asuntos econ\u00F3micos"),
            choices = list(
                "Se encarga de sus asuntos econ\u00F3micos por si solo" = 0,
                "Realiza compras de cada d\u00EDa, pero necesita ayuda en las grandes compras y en los bancos" = 1,
                "No es capaz de administrarse su medicaci\u00F3n" = 2
            ), selected = 5,
            width = "100%"
        )
    ),
    br(),
    br(),
    fluidRow(actionButton("GLAWTONB", "Guardar",
        width = "200px", icon("far fa-save"),
        style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
    ), align = "center")
)