tabPruebasTamizaje <- tabItem(
    "menu_1", h2(strong("ACTIVIDADES Y PRUEBAS DE TAMIZAJE A REALIZAR EN PERSONAS MAYORES"), align = "center"), br(),
    shinyjs::useShinyjs(),
    em("1.Tamizaje de cuello uterino (ADN-VPH) se debe realizar a todas las mujeres entre 30 y 65
                                                anos de edad con un con un esquema 1 - 5 - 5 (cada 5 a\u00F1os) ante resultados negativos."),
    flowLayout(
        selectInput("P1_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P1_PT_date", h5(strong("Fecha"), align = "center"), value = Sys.Date())
    ),
    br(),
    br(),
    em("2. Tamizaje de cuello uterino (citolog \u00EDa) Esquema 1 - 3 - 3 (cada 3 a a\u00F1os) hasta los 65 a\u00F1os."),
    flowLayout(
        selectInput("P2_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P2_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("3. Tamizaje para c\u00E1ncer de mama (mamograf\u00EDa) cada 2 a\u00F1os hasta los 69 a\u00F1os (anotar la fecha)."),
    flowLayout(
        selectInput("P3_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P3_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("4. Tamizaje para c\u00E1ncer de mama (valoraci\u00F3n cl\u00EDnica de la mama) anual hasta los 69 a\u00F1os."),
    flowLayout(
        selectInput("P4_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P4_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("5. Biopsia de mama (seg\u00FAn hallazgos de la mamograf\u00EDa)"),
    flowLayout(
        selectInput("P5_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P5_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("6. Tamizaje para c\u00E1ncer de pr\u00F3stata (PSA) cada 5 a\u00F1os hasta los 75 a\u00F1os (anotar la fecha)."),
    flowLayout(
        selectInput("P6_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P6_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("7. Tamizaje para c\u00E1ncer de pr\u00F3stata (Tacto rectal) cada 5 a\u00F1os, hasta los 75 a\u00F1os."),
    flowLayout(
        selectInput("P7_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P7_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("8. Biopsia de pr\u00F3stata (seg\u00FAn hallazgos en la tamizaci\u00F3n) hasta los 75 a\u00F1os."),
    flowLayout(
        selectInput("P8_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P8_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("9. Tamizaje para c\u00E1ncer de colon (sangre oculta en materia fecal por inmunoqu\u00EDmica) cada 2 a\u00F1os hasta los 75 a\u00F1os (anotar la fecha)"),
    flowLayout(
        selectInput("P9_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P9_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("10. Colonoscopia (seg\u00FAn resultados de sangre oculta) hasta los 75 a\u00F1os."),
    flowLayout(
        selectInput("P10_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P10_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("11. Biopsia de colon (seg\u00FAn hallazgos endosc\u00F3picos)."),
    flowLayout(
        selectInput("P11_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P11_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("12. Tamizaje de riesgo cardiovascular, cada 5 a\u00F1os hasta los 79 a\u00F1os: Glicemia basal,
                             perfil lipidico (colestero HDL, LDL, Colesterol total y triglic\u00E9ridos), creatinina y uroan\u00E1lisis"),
    flowLayout(
        selectInput("P12_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P12_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("13. Prueba r\u00E1pida trepon\u00E9mica (seg\u00FAn la exposici\u00F3n al riesgo)"),
    flowLayout(
        selectInput("P13_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P13_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("14. Prueba r\u00E1pida para VIH (seg\u00FAn exposici\u00F3n al riesgo)"),
    flowLayout(
        selectInput("P14_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P14_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("15. Prueba r\u00E1pida para Hepatitis B (seg\u00FAn exposici\u00F3n al riesgo, relaciones sexuales sin protecci\u00F3n)"),
    flowLayout(
        selectInput("P15_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P15_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("16. Prueba r\u00E1pida para Hepatitis C (para toda la poblaci\u00F3n entre los 50 y 79 a\u00F1os, una vez en la vida)"),
    flowLayout(
        selectInput("P16_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P16_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("17. Asesor\u00EDa en anticoncepci\u00F3n (por demanda solo para la poblaci\u00F3n masculina, hasta los 79 a\u00F1os e incentivar a las
                             mujeres mayores de 60 a\u00F1os a la prevenci\u00F3n de enfermedades de transmisi\u00F3n sexual)."),
    flowLayout(
        selectInput("P17_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P17_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("18. Vasectom\u00EDa (por demanda, hasta los 79 a\u00F1os)."),
    flowLayout(
        selectInput("P18_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P18_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("19. Suministro de preservativos (en consulta se entregar\u00E1n 10 condones al mes de acuerdo a la directriz)."),
    flowLayout(
        selectInput("P19_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P19_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("20. Vacunaci\u00F3n seg\u00FAn esquema vigente de Influenza cada a\u00F1o (gratuita)."),
    flowLayout(
        selectInput("P20_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P20_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("21. Pneumococo conjugada (una sola vez luego de los 50 a\u00F1os)."),
    flowLayout(
        selectInput("P21_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P21_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("22. Pneumococo polisac\u00E1rida, una dosis al a\u00F1o de aplicada la conjugada y repetir a los 5 a\u00F1os (gratuita en Bogot\u00E1)."),
    flowLayout(
        selectInput("P22_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P22_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("23. Vacunaci\u00F3n seg\u00FAn esquema vigente de Herpes zoster (una vez luego de los 50 a\u00F1os)."),
    flowLayout(
        selectInput("P23_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P23_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("24. Educaci\u00F3n individual: h\u00E1bitos y estilos de vida saludable (registrar si cumple recomendaciones de actividad f\u00EDsica)."),
    flowLayout(
        selectInput("P24_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P24_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("25. Educaci\u00F3n dirigida a la familia (de acuerdo a la necesidad se establecer\u00E1n los ciclos y contenidos educativos)."),
    flowLayout(
        selectInput("P25_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P25_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("26. Educaci\u00F3n grupal (de acuerdo a la necesidad se establecer\u00E1n los ciclos y contenidos educativos, se debe derivar por lo menos a
                             tres ciclos educativos. Se debe realizar sesiones educativas grupales para personas cuidadoras. Deben realizarse sesiones educativas
                             de entrenamiento cognitivo y emocional)."),
    flowLayout(
        selectInput("P26_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P26_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("27. Remisi\u00F3n a odontolog\u00EDa para profilaxis y remoci\u00F3n de placa bacteriana (una vez cada dos a\u00F1os)."),
    flowLayout(
        selectInput("P27_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P27_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    em("28. Remisi\u00F3n a odontolog\u00EDa para detartraje supragingival (seg\u00FAn necesidad)."),
    flowLayout(
        selectInput("P28_PT", h5(strong("Respuesta")),
            choices = list("-" = 0, "SI" = "SI", "NO" = "NO"), selected = 0
        ),
        dateInput("P28_PT_date", h5(strong("Fecha"), align = "center"), Sys.Date())
    ),
    br(),
    br(),
    fluidRow(actionButton("PT", "Guardar",
        width = "200px", icon("far fa-save"),
        style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
    ), align = "center"),
    br(),
    br(),
)