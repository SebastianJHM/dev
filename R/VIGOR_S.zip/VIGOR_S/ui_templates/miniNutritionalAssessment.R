tabMiniNutritionalAssessment <- tabItem(
    "sub1_5", h1(strong("MINI NUTRITIONAL ASSESSMENT  MNA"), align = "center"),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "Identificar pacientes desnutridos o en riesgo de desnutrici\u00F3n.")),
        br(),
        radioButtons("MNA_P1", p("Pregunta 1:", br(), em("\u00BFDurante los \u00FAltimos tres meses ha comido menos por falta de apetito,
                                                      problemas digestivos, dificultades para masticar o para tragar la com\u00EDda\u003F (Respuesta \u00FAnica)")),
            choices = list(
                "Ha comido mucho menos" = 0,
                "Ha comido menos" = 1,
                "Ha comido igual" = 2
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P2", p("Pregunta 2:", br(), em("P\u00E9rdida reciente de peso (<3 meses)")),
            choices = list(
                "P\u00E9rdida de peso > 3 Kg" = 0,
                "No lo sabe" = 1,
                "P\u00E9rdida de peso entre 1 y 3 Kg" = 2,
                "No ha habido p\u00E9rdida de peso" = 3
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P3", p("Pregunta 3:", br(), em("Movilidad (independencia funcional)")),
            choices = list(
                "De la cama al sill\u00F3n" = 0,
                "No lo sabe" = 1,
                "Autonom\u00EDa en el interior de la casa" = 2,
                "Sale del domicilio" = 3
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P4", p("Pregunta 4:", br(), em("\u00BFHa tenido una enfermedad aguda o situaci\u00F3n de estr\u00E9s psicol\u00F3gico en los \u00FAltimos 3 meses\u003F")),
            choices = list(
                "Si" = 0,
                "No lo sabe" = 1,
                "No" = 2
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P5", p("Pregunta 5:", br(), em("Problemas neuropsicol\u00F3gicos")),
            choices = list(
                "Demencia o depresi\u00F3n grave" = 0,
                "No lo sabe" = 1,
                "Demencia moderada" = 2,
                "Sin problemas psicol\u00F3gicos" = 3
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P6", p("Pregunta 6:", br(), em("\u00EDndice de masa corporal (IMC=peso/(talla)2 en Kg/m2)")),
            choices = list(
                "IMC <19" = 0,
                "19 < o igual IMC < 21" = 1,
                "21 < o igual IMC < 23" = 2,
                "IMC > o igual a 23" = 3
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P7", p("Pregunta 7:", br(), em("\u00BFLa persona mayor vive independiente en su domicilio\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P8", p("Pregunta 8:", br(), em("\u00BFToma m\u00E1s de 3 medicamentos al d\u00EDa\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P9", p("Pregunta 9:", br(), em("\u00BFTiene \u00FAlceras o lesiones en la piel\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P10", p("Pregunta 10:", br(), em("\u00BFCu\u00E1ntas comidas completas realiza al d\u00EDa\u003F")),
            choices = list(
                "Una comida" = 0,
                "Dos comidas" = 1,
                "Tres o m\u00E1s comidas" = 2
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P11.1", p("Pregunta 11:", br(), em("\u00BFConsume leche, queso u otros productos l\u00E1cteos al menos una vez al d\u00EDa\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        radioButtons("MNA_P11.2", p(br(), em("\u00BFHuevos o legumbres 1 o 2 veces a la semana\u003F (Ej: leguminosas = frijol, lenteja, garbanzos, soya, habas, man\u00ED)")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        radioButtons("MNA_P11.3", p(br(), em("\u00BFCarne, pescado o aves\u003F (Ej: carnes: si le mencionan, salchich\u00F3n, salchichas, jam\u00F3n, etc. tambi\u00E9n se incluyen aqu\u00ED)")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P12", p("Pregunta 12:", br(), em("\u00BFConsume frutas o verduras al menos dos veces al d\u00EDa\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P13", p("Pregunta 13:", br(), em("\u00BFCu\u00E1ntos vasos de agua u otros l\u00EDquidos toma al d\u00EDa\u003F (agua, jugo, caf\u00E9, t\u00E9, leche, vino, cerveza, etc.)")),
            choices = list(
                "Menos de 3 vasos" = 0,
                "De 3 a 5 vasos" = 1,
                "M\u00E1s de 5 vasos" = 2
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P14", p("Pregunta 14:", br(), em("Forma de alimentarse")),
            choices = list(
                "Necesita ayuda" = 0,
                "Se alimenta solo con dificultad" = 1,
                "Se alimenta solo sin dificultad" = 2
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P15", p("Pregunta 15:", br(), em("Respecto a su estado nutricional \u00BFse considera usted con desnutrici\u00F3n grave, desnutrici\u00F3n moderada o bien nutrido\u003F")),
            choices = list(
                "Malnutrici\u00F3n grave" = 0,
                "No lo sabe o malnutrici\u00F3n moderada" = 1,
                "Sin problemas, bien nutrido" = 2
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P16", p("Pregunta 16:", br(), em("En comparaci\u00F3n con las personas de su edad, \u00BFc\u00F3mo encuentra la persona mayor su estado de salud\u003F")),
            choices = list(
                "Peor" = 0,
                "No lo sabe" = 1,
                "Igual" = 2,
                "Mejor" = 3
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P17", p("Pregunta 17:", br(), em("Circunferencia braquial (CB en cm)")),
            choices = list(
                "CB < 21" = 0,
                "CB 21 < o igual CB < o igual de 22" = 1,
                "CB > 22" = 2,
                "NA" = 3
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("MNA_P18", p("Pregunta 18:", br(), em("Circunferencia de pantorrilla (CP en cm)")),
            choices = list(
                "CP < de 31  " = 0,
                "CP > o igual a 31" = 1,
                "NA" = 2
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        fluidRow(actionButton("G_MNA", "Guardar",
            width = "200px", icon("far fa-save"),
            style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
        ), align = "center"),
        br(),
        textOutput("Resultado_MNA")
    )
)