tabRiesgoTromboembolico_ACV <- tabItem(
    "sub2_2", h3("RiesgoTromboembolico/ACV"),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "Valoraci\u00F3n del riesgo de ACV en pacientes con FA")),
        br(),
        flowLayout(
            radioButtons("RACV_P1", p("Pregunta 1:", br(), em("Insuficiencia cardiaca congestiva / disfunci\u00F3n VI")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("RACV_P2", p("Pregunta 2:", br(), em("Hipertensi\u00F3n")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("RACV_P3", p("Pregunta 3:", br(), em("Diabetes mellitus")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("RACV_P4", p("Pregunta 4:", br(), em("ACV / AIT / tromboembolismo")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("RACV_P5", p("Pregunta 5:", br(), em("Enfermedad vascular")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            )
        ),
        br(),
        br(),
        fluidRow(actionButton("G_RACV", "Guardar",
            width = "200px", icon("far fa-save"),
            style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
        ), align = "center"),
        br(),
        textOutput("Resultado_RACV")
    )
)