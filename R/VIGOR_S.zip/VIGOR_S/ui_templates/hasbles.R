tabHasbles <- tabItem(
    "sub2_3", h3("Hasbles"),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "Valoraci\u00F3n del riesgo de sangrado en paciente anticoagulado")),
        br(),
        flowLayout(
            radioButtons("HASB_P1", p("Pregunta 1:", br(), em("Hipertensi\u00F3n")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("HASB_P2", p("Pregunta 2:", br(), em("Funci\u00F3n renal anormal")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("HASB_P3", p("Pregunta 3:", br(), em("Funci\u00F3n hep\u00E1tica anormales")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("HASB_P4", p("Pregunta 4:", br(), em("ACV")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("HASB_P5", p("Pregunta 5:", br(), em("Hemorragia")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("HASB_P6", p("Pregunta 6:", br(), em("INR inestables")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("HASB_P7", p("Pregunta 7:", br(), em("Consume drogas")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            ),
            radioButtons("HASB_P8", p("Pregunta 8:", br(), em("Consume alcohol")),
                choices = list(
                    "Si" = 0,
                    "No" = 1
                ), selected = 5,
                width = "100%"
            )
        ),
        br(),
        br(),
        fluidRow(actionButton("G_HASB", "Guardar",
            width = "200px", icon("far fa-save"),
            style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
        ), align = "center"),
        br(),
        textOutput("Resultado_HASB")
    )
)