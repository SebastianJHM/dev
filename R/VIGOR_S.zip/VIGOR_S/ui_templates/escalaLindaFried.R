tabEscalaLindaFriend <- tabItem(
    "sub1_4", h1(strong("Escala de Linda Fried"), align = "center"),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "detectar tempranamente a las personas adultas mayores con pre-fragilidad y fragilidad.")),
        br(),
        br(),
        fluidRow(div(style = "color: #fff;background-color: #7FA3B1;", "1.Perdida involuntaria de peso")),
        br(),
        radioButtons("LINDAF_P1", p("Pregunta 1:", br(), em("\u00BFEn el \u00FAltimo a\u00F1o, usted ha perdido m\u00E1s de 5 kg de peso, sin intensi\u00F3n\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("LINDAF_P2", p("Pregunta 2:", br(), em("\u00BFEn los \u00FAltimos 3 meses ha perdido peso sin intenci\u00F3n\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("LINDAF_P3", p("Pregunta 3:", br(), em("C\u00E1lculo de \u00EDndice de masa corporal IMC (peso/talla2) Marque SI, si el c\u00E1lculo de IMC es igual o inferior a
                                                                             21 Kg/m2")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        fluidRow(div(style = "color: #fff;background-color: #7FA3B1;", "2.Baja actividad f\u00EDsica")),
        br(),
        radioButtons("LINDAF_P4", p("Pregunta 4:", br(), em("\u00BFParticipa usted al menos tres veces por semana, en alguna actividad deportiva o hace ejercicio como nadar,
                                                                             trotar, jugar tenis, montar en bicicleta, hacer aer\u00F3bicos, clases de gimnasia u otras actividades, que le causen
                                                                             sudoraci\u00F3n o que lo dejen sin respiraci\u00F3n\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("LINDAF_P5", p("Pregunta 5:", br(), em("\u00BFCamina usted, al menos tres veces por semana, entre 9 y 20 cuadras (1.6 Km) sin descansar\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("LINDAF_P6", p("Pregunta 6:", br(), em("\u00BFCamina usted, al menos tres veces por semana menos de 8 cuadras (0.5 Km) sin descansar\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("LINDAF_P7", p("Pregunta 7:", br(), em("Ninguna de las anteriores")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        fluidRow(div(style = "color: #fff;background-color: #7FA3B1;", "3.Autorreporte de cansancio f\u00EDsico (fatiga o agotamiento)")),
        br(),
        radioButtons("LINDAF_P8", p("Pregunta 8:", br(), em("\u00BFSiente usted que vive cansado/a todo el tiempo\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        fluidRow(div(style = "color: #fff;background-color: #7FA3B1;", "4.La disminuci\u00F3n de la fuerza de agarre (dinamometr\u00EDa - ver puntos de corte)")),
        br(),
        radioButtons("LINDAF_P9", p("Pregunta 9:", br(), em("Se mide la fuerza muscular prensil de la mano y el antebrazo con dinam\u00F3metro, teniendo
                                                                             en cuenta los puntos de corte para Colombia que se muestran a continuaci\u00F3n. Marque SI, si
                                                                             la medida de fuerza de agarre obtenida en la medici\u00F3n de acuerdo al rango de edad est\u00E1 por
                                                                             debajo del punto de corte. ")),
            choices = list(
                "Si" = 0,
                "No" = 1,
                "No se realiza" = 2
            ), selected = 5,
            width = "100%"
        ),
        img(src = "LindaFried.png"),
        br(),
        br(),
        fluidRow(div(style = "color: #fff;background-color: #7FA3B1;", "5.Velocidad de la marcha")),
        br(),
        radioButtons("LINDAF_P10", p("Pregunta 10:", br(), em("En un trayecto de 4 metros decirle a la persona que camine a la velocidad que normalmente camina sin
                                                                               que pare de forma abrupta cuando termine los 4 metros. Se mide el tiempo con cron\u00F3metro y se registra la
                                                                               velocidad de la marcha. (Se pueden hacer dos mediciones dejando un minuto de intervalo entre ellas y se
                                                                               consigna el mejor tiempo obtenido). Marque SI, si la velocidad obtenida es menor o igual a 0.8 m/seg.")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        )
    ),
    br(),
    br(),
    fluidRow(actionButton("G_LINDAF", "Guardar",
        width = "200px", icon("far fa-save"),
        style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
    ), align = "center"),
    br(),
    textOutput("Resultado_LF")
)