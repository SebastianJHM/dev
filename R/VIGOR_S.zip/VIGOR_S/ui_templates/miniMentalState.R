tabMiniMentalState <- tabItem(
    "sub1_1", h1(strong("Mini Mental State"), align = "center"), br(),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "valorar el estado cognoscitivo de las personas adultas mayores.")),
        br(),
        br(),
        flowLayout(
            selectInput("MinM_P1", p("Pregunta 1:", br(), em("En que ano estamos"), br(), br()),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P2", p("Pregunta 2:", br(), em("En que mes estamos"), br(), br()),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P3", p("Pregunta 3:", br(), em("En que dia estamos"), br(), br()),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P4", p("Pregunta 4:", br(), em("Dia de la semana"), br(), br()),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P5", p("Pregunta 5:", br(), em("Hora (manana - tarde - noche)"), br(), br()),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P6", p("Pregunta 6:", br(), em("En que pais estamos"), br(), br()),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P7", p("Pregunta 7:", br(), em("En que departamento estamos"), br(), br()),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P8", p("Pregunta 8:", br(), em("En que ciudad estamos"), br(), br()),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P9", p("Pregunta 9:", br(), em("En que barrio o localidad (vereda)"), br(), br()),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P10", p("Pregunta 10:", br(), em("Lugar o piso donde nos encontramos")),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            )
        ),
        br(),
        strong("Pregunta 11"),
        br(),
        em("Repita las siguientes palabras: CASA, MESA, ARBOL. Grabese estas
                                                        palabras porque mas adelante se las voy a preguntar"),
        br(),
        br(),
        flowLayout(
            selectInput("MinM_P12", p(em("Cuantas palabras acerto"), br(), br()),
                choices = list("-" = 0, "0" = 0, "1" = 1, "2" = 2, "3" = 3)
            ),
            numericInput("MinM_P11b", p(em("Numero de ensayos requeridos para acertar las tres palbras"), align = "center"), "-", max = 10, min = 0)
        ),
        br(),
        strong("Pregunta 12"),
        br(),
        em("Restar de 100 - 7 en forma sucesiva. Pare a la quinta respuesta. Registre un punto por cada
                               respuesta correcta. (93, 86, 79, 72, 65) - tambien se puede reemplazar por decir los meses del ano al reves
                               (Diciembre, Noviembre, Octubre...)"),
        flowLayout(
            selectInput("MinM_P13", p(br()),
                choices = list("-" = 0, "0" = 1, "1" = 2, "2" = 3, "3" = 4, "4" = 5, "5" = 6)
            )
        ),
        br(),
        strong("Pregunta 13"),
        br(),
        em("Recuerde las tres palabras que le repeti antes. Registre el numero de palabras que recuerde."),
        flowLayout(
            selectInput("MinM_P14", p(br()),
                choices = list("-" = 0, "0" = 1, "1" = 2, "2" = 3, "3" = 4)
            )
        ),
        br(),
        strong("Pregunta 14"),
        br(),
        em("Denominar dos objetos: que es esto (Y senalar un reloj, lapiz, entre otros objetos comunes)."),
        flowLayout(
            selectInput("MinM_P15", p(br()),
                choices = list("-" = 0, "0" = 1, "1" = 2, "2" = 3)
            )
        ),
        br(),
        strong("Pregunta 15"),
        br(),
        em("Repetir: En un trigal habia cinco perros. (Marcar 1 punto si el paciente repitio perfectamente)."),
        flowLayout(
            selectInput("MinM_P16", p(br()),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            )
        ),
        br(),
        strong("Pregunta 16"),
        br(),
        em("Comprension: Obedecer una orden en tres etapas: tome la hoja con su mano derecha, doblela por
                               la mitad y pongala en el suelo (Cada etapa corresponde a 1 punto)"),
        flowLayout(
            selectInput("MinM_P17", p(br()),
                choices = list("-" = 0, "0" = 1, "1" = 2, "2" = 3, "3" = 4)
            )
        ),
        strong("Pregunta 18"),
        br(),
        em("Lea y obedezca las siguientes ordenes, (Marcar 1 punto si el paciente obedecio las ordenes)"),
        br(),
        br(),
        flowLayout(
            selectInput("MinM_P19", p(em("Cierre los ojos")),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P20", p(em("Escriba una frase")),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            ),
            selectInput("MinM_P21", p(em("Copie el diseno o dibujo"), img(src = "Img1.png")),
                choices = list("-" = 0, "Correcto" = "Correcto", "Incorrecto" = "Incorrecto")
            )
        )
    ),
    br(),
    br(),
    fluidRow(actionButton("GMMental", "Guardar",
        width = "200px", icon("far fa-save"),
        style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
    ), align = "center")
)