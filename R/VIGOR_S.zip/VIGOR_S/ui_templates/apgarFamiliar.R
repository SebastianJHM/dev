tabApgarFamiliar <- tabItem(
    "sub1_9", h1(strong("APGAR Familiar"), align = "center"),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "Cuestionario para la evaluacion de la funcionalidad en la familia"))
    ),
    br(),
    flowLayout(
        selectInput("AP_P1", p("Pregunta 1:", br(), em("Le satisface la ayuda que recibe de su familia cuando tiene algun problema y/o necesidad"), br(), br()),
            choices = list(
                "-" = 0, "Nunca" = 1, "Casi nunca" = 2,
                "Algunas veces" = 3, "Casi siempre" = 4,
                "Siempre" = 5
            ), selected = 0
        ),
        selectInput("AP_P2", p("Pregunta 2:", br(), em("Le satisface como en su familia hablan y comparten sus problemas"), br(), br(), br()),
            choices = list(
                "-" = 0, "Nunca" = 1, "Casi nunca" = 2,
                "Algunas veces" = 3, "Casi siempre" = 4,
                "Siempre" = 5
            ), selected = 0
        ),
        selectInput("AP_P3", p("Pregunta 3:", br(), em("Le satisface como en su familia aceptan y apoyan su deseo de emprender nuevas actividades"), br(), br()),
            choices = list(
                "-" = 0, "Nunca" = 1, "Casi nunca" = 2,
                "Algunas veces" = 3, "Casi siempre" = 4,
                "Siempre" = 5
            ), selected = 0
        ),
        selectInput("AP_P4", p("Pregunta 4:", br(), em("Le satisface como su familia expresa afecto y responde a sus emociones tales
                                                              como rabia, tristeza, amor")),
            choices = list(
                "-" = 0, "Nunca" = 1, "Casi nunca" = 2,
                "Algunas veces" = 3, "Casi siempre" = 4,
                "Siempre" = 5
            ), selected = 0
        ),
        selectInput("AP_P5", p("Pregunta 5:", br(), em("Le satisface como compartimos en mi familia en ambitos generales"), br(), br(), br()),
            choices = list(
                "-" = 0, "Nunca" = 1, "Casi nunca" = 2,
                "Algunas veces" = 3, "Casi siempre" = 4,
                "Siempre" = 5
            ), selected = 0
        ),
        selectInput("AP_P6", p("Pregunta 6:", br(), em("Le satisface como compartimos en mi familia el tiempo para estar juntos"), br(), br()),
            choices = list(
                "-" = 0, "Nunca" = 1, "Casi nunca" = 2,
                "Algunas veces" = 3, "Casi siempre" = 4,
                "Siempre" = 5
            ), selected = 0
        ),
        selectInput("AP_P7", p("Pregunta 7:", br(), em("Le satisface como compartimos en mi familia los espacios en la casa"), br(), br(), br()),
            choices = list(
                "-" = 0, "Nunca" = 1, "Casi nunca" = 2,
                "Algunas veces" = 3, "Casi siempre" = 4,
                "Siempre" = 5
            ), selected = 0
        ),
        selectInput("AP_P8", p("Pregunta 8:", br(), em("Le satisface como compartimos en mi familia el dinero"), br(), br(), br()),
            choices = list(
                "-" = 0, "Nunca" = 1, "Casi nunca" = 2,
                "Algunas veces" = 3, "Casi siempre" = 4,
                "Siempre" = 5
            ), selected = 0
        ),
        selectInput("AP_P9", p("Pregunta 9:", br(), em("Usted tiene un(a) amigo(a) cercano a quien pueda buscar cuando necesite ayuda"), br(), br()),
            choices = list(
                "-" = 0, "Nunca" = 1, "Casi nunca" = 2,
                "Algunas veces" = 3, "Casi siempre" = 4,
                "Siempre" = 5
            ), selected = 0
        ),
        selectInput("AP_P10", p("Pregunta 10:", br(), em("Estoy satisfecho(a) con el soporte que recibo de mis amigos (as)"), br(), br(), br()),
            choices = list(
                "-" = 0, "Nunca" = 1, "Casi nunca" = 2,
                "Algunas veces" = 3, "Casi siempre" = 4,
                "Siempre" = 5
            ), selected = 0
        )
    ),
    br(),
    br(),
    fluidRow(actionButton("GApgar", "Guardar",
        width = "200px", icon("far fa-save"),
        style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
    ), align = "center"),
    br(),
    textOutput("Resultado_AP"),
    br(),
    textOutput("Resultado_AP_F")
)