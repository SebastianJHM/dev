tabValoracionFramingham <- tabItem(
    "sub1_6", h1(strong("Valoraci\u00F3n Framingham"), align = "center"),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "Evaluaci\u00F3n del riesgo cardiovascular")),
        br(),
        numericInput("FRAMI_P1", p("Pregunta 1:", br(), em("Colesterol toltal mg/DL")), value = ""),
        br(),
        radioButtons("FRAMI_P2", p("Pregunta 2:", br(), em("\u00BFFuma\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        numericInput("FRAMI_P3", p("Pregunta 3:", br(), em("HDL mg/dl")), value = ""),
        br(),
        numericInput("FRAMI_P4.1", p("Pregunta 4:", br(), em("Presi\u00F3n sist\u00F3lica mmHg")), value = ""),
        radioButtons("FRAMI_P4.2", p(em("\u00BFEs tratada\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        fluidRow(actionButton("G_FRAMI", "Guardar",
            width = "200px", icon("far fa-save"),
            style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
        ), align = "center"),
        br(),
        textOutput("Resultado_FRAMI")
    )
)