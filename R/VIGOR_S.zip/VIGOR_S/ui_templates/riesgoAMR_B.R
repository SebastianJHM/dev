tabRiesgoAMR_B <- tabItem(
    "sub1_8", h1(strong("RiesgoAMR B"), align = "center"),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "riesgo de padecer un episodio cardiovascular, mortal o no, en un periodo de 10 a\u00F1os")),
        br(),
        radioButtons("AMRB_P1", p("Pregunta 1:", br(), em("\u00BFSe puede medir el colestreol sangu\u00EDneo\u003F Colesterol (mmol/l)")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        selectInput("AMRB_P1.1", p(),
            choices = list(
                "-" = 0,
                "4" = 1,
                "5" = 2,
                "6" = 3,
                "7" = 4,
                "8" = 5
            )
        ),
        br(),
        selectInput("AMRB_P2", p("Pregunta 2:", br(), em("\u00BFCual es la presi\u00F3n arterial sist\u00F3lica (PAS)\u003F")),
            choices = list(
                "-" = 0,
                ">=160" = 1,
                "140 - <160" = 2,
                "120 - <140" = 3,
                "<120" = 4
            )
        ),
        br(),
        radioButtons("AMRB_P3", p("Pregunta 3:", br(), em("\u00BFFuma\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("AMRB_P4", p("Pregunta 4:", br(), em("\u00BFTiene diabetes mellitus\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        fluidRow(actionButton("G_AMRB", "Guardar",
            width = "200px", icon("far fa-save"),
            style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
        ), align = "center"),
        br(),
        textOutput("Resultado_AMRB")
    )
)