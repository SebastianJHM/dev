tabEscalaBarthel <- tabItem(
    "sub1_2", h1(strong("Escala de Barthel"), align = "center"), br(),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "determinar la capacidad de la persona adulta mayor para realizar las actividades b\u00E1sicas
                                        de la vida diaria que le permiten ser aut\u00F3nomo e independiente.")),
        br(),
        br(),
        radioButtons("BARTHEL_P1", em("1.Comer"),
            choices = list(
                "Es capaz por si solo de utilizar cualquier instrumento necesario; come en un tiempo razonable;
                                                                         capaz de desmenuzar la comida, usar condimentos, extender la mantequilla, etc., por s\u00ED solo " = 0,
                "Necesita ayuda para cortar la carne o el pan, extender la mantequilla, etc., pero es capaz de comer
                                                                         solo " = 1, "Necesita ser alimentado por otra persona" = 2
            ), selected = 5, width = "100%"
        ),
        br(),
        br(),
        radioButtons("BARTHEL_P2", em("2.Ba\u00F1arse"),
            choices = list(
                "Capaz de ba\u00F1arse todo el cuerpo, puede ser usando la ducha, la ba\u00F1era o permaneciendo de pie y aplicando jab\u00F3n
                                           sobre todo el cuerpo.Incluye entrar y salir del ba\u00F1o. Puede realizarlo todo sin estar una persona presente." = 0,
                "Necesita alguna ayuda o supervisi\u00F3n " = 1
            ), selected = 5, width = "100%"
        ),
        br(),
        br(),
        radioButtons("BARTHEL_P3", em("3.Vestirse"),
            choices = list(
                "Capaz de poner y quitarse la ropa, atarse los zapatos, abrocharse los botones y colocarse otros complementos que precisa (por ejemplo,
                                                        cremalleras, cordones, etc.) sin ayuda" = 0, "Necesita ayuda, pero puede hacer la mitad aproximadamente, sin ayuda" = 1,
                "Lo tienen que vestir" = 2
            ), selected = 5, width = "100%"
        ),
        br(),
        br(),
        radioButtons("BARTHEL_P4", em("4.Aseo personal"),
            choices = list("Realiza todas las actividades personales sin ninguna ayuda. Incluye lavarse cara y manos, peinarse, maquillarse, afeitarse y cepillarse
                                                        los dientes. Los complementos necesarios para ello pueden ser provistos por otra persona " = 0, "Necesita alguna ayuda o supervisi\u00F3n" = 1), selected = 5, width = "100%"
        ),
        br(),
        br(),
        radioButtons("BARTHEL_P5", em("5.Deposici\u00F3n"),
            choices = list(
                "No ha presentado ning\u00FAn episodio de incontinencia fecal. Si necesita enema o supositorios es capaz de administr\u00E1rselos por s\u00ED solo" = 0,
                "Presenta incontinencia fecal menos de una vez por semana o necesita ayuda para enemas o supositorios" = 1,
                "Requiere uso de enemas o supositorios por otro" = 2
            ), selected = 5, width = "100%"
        ),
        br(),
        br(),
        radioButtons("BARTHEL_P6", em("6.Micci\u00F3n"),
            choices = list(
                "No ha presentado ning\u00FAn episodio de incontinencia fecal. Si necesita enema o supositorios es capaz de administr\u00E1rselos por s\u00ED solo" = 0,
                "Presenta incontinencia fecal menos de una vez por semana o necesita ayuda para enemas o supositorios" = 1,
                "Requiere uso de enemas o supositorios por otro" = 2
            ), selected = 5, width = "100%"
        ),
        br(),
        br(),
        radioButtons("BARTHEL_P7", em("7.Uso de retrete"),
            choices = list(
                "Entra y sale solo. Es capaz de quitarse y ponerse la ropa, limpiarse, prevenir el manchado de la ropa, vaciar y limpiar la cu\u00F1a. Capaz de sentarse y
                                                        levantarse sin ayuda. Puede utilizar barras de soporte" = 0, "Necesita ayuda para mantener el equilibrio, quitarse o ponerse la ropa o limpiarse " = 1,
                "Incapaz de manejarse sin asistencia mayor" = 2
            ), selected = 5, width = "100%"
        ),
        br(),
        br(),
        radioButtons("BARTHEL_P8", em("8.Traslado sill\u00F3n cama"),
            choices = list(
                "No necesita ayuda. Si utiliza silla de ruedas, lo hace independientemente." = 0,
                "Incluye supervisi\u00F3n verbal o peque\u00F1a ayuda f\u00EDsica" = 1, "Capaz de estar sentado sin ayuda, pero necesita mucha asistencia para entrar o salir de
                                                        la cama" = 2, "Necesita gr\u00FAa o alzamiento completo por dos personas. Incapaz de permanecer sentado" = 3
            ), selected = 5, width = "100%"
        ),
        br(),
        br(),
        radioButtons("BARTHEL_P9", em("9.Desplazamiento"),
            choices = list(
                "Puede usar cualquier ayuda (pr\u00F3tesis, bastones, muletas, etc.), excepto andador. La velocidad no es importante. Puede caminar al menos 50 m o
                                                        equivalente sin ayuda o supervisi\u00F3n" = 0, "Supervisi\u00F3n f\u00EDsica o verbal, incluyendo instrumentos u otras ayudas para permanecer de pie. Deambula 50 m" = 1,
                "Propulsa su silla de ruedas al menos 50 m. Gira esquinas solo." = 2, "Requiere ayuda mayor" = 3
            ), selected = 5, width = "100%"
        ),
        br(),
        br(),
        radioButtons("BARTHEL_P10", em("10.Subir y bajar escaleras (no el\u00E9ctricas)"),
            choices = list(
                "Capaz de subir y bajar un piso de escaleras sin ayuda o supervisi\u00F3n, aunque utilice barandilla o instrumentos de apoyo" = 0,
                "Supervisi\u00F3n f\u00EDsica o verbal" = 1, "Necesita alzamiento (ascensor) o Es incapaz de subir y bajar un piso, necesita ascensor o que lo alcen" = 2
            ), selected = 5,
            width = "100%"
        )
    ),
    br(),
    br(),
    fluidRow(actionButton("GBARTHEL", "Guardar",
        width = "200px", icon("far fa-save"),
        style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
    ), align = "center")
)