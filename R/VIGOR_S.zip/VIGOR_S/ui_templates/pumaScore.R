tabPumaScore <- tabItem(
    "sub2_1", h3("Puma Score"),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "Detecci\u00F3n de casos de EPOC")),
        br(),
        radioButtons("PUMAS_P1", p("Pregunta 1:", br(), em("\u00BFAlguna vez en la vida ha fumado\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        sliderInput("PUMAS_P1.1", p(em("Promedio de cigarillos por d\u00EDa")), min = 0, max = 50, value = 0),
        sliderInput("PUMAS_P1.2", p(em("N\u00FAmero de a\u00F1os fumando")), min = 0, max = 100, value = 0),
        br(),
        radioButtons("PUMAS_P2", p("Pregunta 2:", br(), em("\u00BFSiente ud. que le falta aire en alg\u00FAn momento cuando camina m\u00E1s r\u00E1pido en un terreno
                                                        plano o en una peque\u00F1a subida\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("PUMAS_P3", p("Pregunta 3:", br(), em("\u00BFGeneralmente tiene ud. Flemas que vienen de su pulm\u00F3n o flemas dif\u00EDciles de sacar sin que est\u00E9
                                                        resfriado(a)\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("PUMAS_P4", p("Pregunta 4:", br(), em("\u00BFGeneralmente tiene usted tos sin que est\u00E9 resfriado (a)\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("PUMAS_P5", p("Pregunta 5:", br(), em("Alguna vez en su vida un m\u00E9dico u otro profesional de la salud le ha pedido que sople en un aparato (llamado
                                                        espir\u00F3metro o picoflujo) para conocer la funci\u00F3n de su pulm\u00F3n\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        br(),
        fluidRow(actionButton("G_PUMAS", "Guardar",
            width = "200px", icon("far fa-save"),
            style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
        ), align = "center"),
        br(),
        textOutput("Resultado_PUMAS")
    )
)