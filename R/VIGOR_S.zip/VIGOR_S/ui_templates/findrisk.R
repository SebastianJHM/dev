tabFindrisk <- tabItem(
    "sub1_7", h1(strong("Findrisk"), align = "center"),
    shinyjs::useShinyjs(),
    fluidPage(
        fluidRow(em(strong("Objetivo de aplicacion:"), "prever cu\u00E1l es su riesgo de enfermar de diabetes tipo 2 en los pr\u00F3ximos 10 a\u00F1os")),
        br(),
        radioButtons("FIND_P1", 
            p("Pregunta 1:", br(), em("\u00BFHa habido un diagn\u00F3stico de diabetes en, por lo menos, un miembro de su familia\u003F")),
            choices = list(
                "No" = 0,
                "S\u00ED, en mis parientes: abuelos, t\u00EDos y primos" = 1,
                "S\u00ED, en mi familia directa: padres, hijos, hermanos" = 2
            ), selected = 5,
            width = "100%"
        ),
        br(),
        selectInput("FIND_P2", p("Pregunta 2:", br(), em("\u00BFQu\u00E9 per\u00EDmetro de cintura tiene, medido a nivel del ombligo\u003F (Si no tiene una cinta m\u00E9trica, use un pedazo
                                                         de cuerda y ay\u00FAdese con una regla)")),
            choices = list(
                "-" = 0,
                "Menos de 94 cms" = 1,
                "94 hasta 102 cms" = 2,
                "M\u00E1s de 102 cms" = 3,
                "No se realiza" = 4
            )
        ),
        br(),
        radioButtons("FIND_P3", p("Pregunta 3:", br(), em("\u00BFTiene actividad f\u00EDsica  por lo menos 30 minutos\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("FIND_P4", p("Pregunta 4:", br(), em("\u00BFCon qu\u00E9 frecuencia come fruta, verduras o pan (de centeno o integral)\u003F")),
            choices = list(
                "Diario" = 0,
                "No diariamente" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("FIND_P5", p("Pregunta 5:", br(), em("\u00BFLe han recetado alguna vez medicamentos contra la hipertensi\u00F3n\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        radioButtons("FIND_P6", p("Pregunta 6:", br(), em("\u00BFLe han detectado alguna vez, en un control m\u00E9dico, un nivel muy alto de glucosa (az\u00FAcar) en su sangre\u003F")),
            choices = list(
                "Si" = 0,
                "No" = 1
            ), selected = 5,
            width = "100%"
        ),
        br(),
        sliderInput("FIND_P7", p("Pregunta 7:", br(), em("Estatura (centimetro)")), min = 0, max = 300, value = 150),
        br(),
        sliderInput("FIND_P8", p("Pregunta 8:", br(), em("Peso (KG)")), min = 0, max = 300, value = 150),
        br(),
        br(),
        fluidRow(actionButton("G_FIND", "Guardar",
            width = "200px", icon("far fa-save"),
            style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
        ), align = "center"),
        br(),
        textOutput("Resultado_FIND")
    )
)