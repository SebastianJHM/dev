source(file = "ui_templates/registro.R")
source(file = "ui_templates/pruebasTamizaje.R")
source(file = "ui_templates/miniMentalState.R")
source(file = "ui_templates/escalaBarthel.R")
source(file = "ui_templates/escalaLawtonBrody.R")
source(file = "ui_templates/escalaLindaFried.R")
source(file = "ui_templates/miniNutritionalAssessment.R")
source(file = "ui_templates/valoracionFramingham.R")
source(file = "ui_templates/findrisk.R")
source(file = "ui_templates/riesgoAMR_B.R")
source(file = "ui_templates/apgarFamiliar.R")
source(file = "ui_templates/pumaScore.R")
source(file = "ui_templates/riesgoTromboembolico_ACV.R")
source(file = "ui_templates/hasbles.R")
source(file = "ui_templates/resultados.R")



dashboardPage(
    
    skin = "green",
    
    
    ################## NOMBRE DE LA APP ###########################
    dashboardHeader(
        title = "VIGOR"
    ),
    
    ################## PESTANAS DE LA APP ##########################
    dashboardSidebar(
        sidebarMenu(
            id = "sbmenu",
            menuItem("Inicio", tabName = "menu_0"),
            menuItemOutput("recOpt"),
            menuItemOutput("recOpt2"),
            menuItemOutput("recOpt3"),
            menuItemOutput("recOpt4")
        )
    ),
    
    #### DISENO DE LA APP ####
    dashboardBody(
        
        tags$head(
            tags$link(rel = "stylesheet", type = "text/css", href = "style.css")
        ),
        
        tabItems(
            
            
            ### REGISTRO ####
            tabRegistro,
            
            ### PRUEBAS DE TAMIZAJE ###
            tabPruebasTamizaje,
            
            
            ##################### Escalas obligatorias #####################
            ### 1. Mini Mental State ###
            tabMiniMentalState,
            
            ### 2. Escala de Barthel ###
            tabEscalaBarthel,
            
            ### 3. Escala de Lawton Brody ###
            tabEscalaLawtonBrody,
            
            ### 4. Escala de Linda Fried ###
            tabEscalaLindaFriend,
            
            ### 5. MINI NUTRITIONAL ASSESSMENT  MNA ###
            tabMiniNutritionalAssessment,
            
            ### 6. ValoraciOn Framingham ###
            tabValoracionFramingham,
            
            ### 7. Findrisk ###
            tabFindrisk,
            
            ### 8. RiesgoAMR B ###
            tabRiesgoAMR_B,
            
            ### 9. APGAR Familiar ###
            tabApgarFamiliar,
            
            
            
            
            ##################### Escalas adicionales #####################
            ### 1. Puma Score ###
            tabPumaScore,
            
            #### 2. RiesgoTromboembolico/ACV ###
            tabRiesgoTromboembolico_ACV,
            
            ### 3. Hasbles ###
            tabHasbles,
            
            
            ###################### Resultados ######################
            tabResultados
        )
    )
)
    

