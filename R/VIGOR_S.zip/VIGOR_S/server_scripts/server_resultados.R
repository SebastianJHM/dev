resultados_functions <- function(input, output, session) {
    observeEvent(input$G_RESULTADOS, {
        BASE <- BASE %>% rbind(BASE2)
        save(BASE, file = "BASE.Rdata")
    })
}