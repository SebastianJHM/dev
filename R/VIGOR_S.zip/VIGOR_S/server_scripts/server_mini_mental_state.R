validacion_campos_mms <- function(input) {
    return(0)
}

mini_mental_state_functions <- function(input, output, session) {
    observeEvent(input$GMMental, {
        validacion_campos_mms(input)
    })
}