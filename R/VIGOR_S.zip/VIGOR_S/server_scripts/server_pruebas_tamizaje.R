val_pregunta <- function(input, i) {
    v <- TRUE
    m <- ""
    
    id <- paste("P",toString(i),"_PT",sep="")
    id_date <- paste("P",toString(i),"_PT_date",sep="")
    
    if (input[[id]] == 0) {
        v <- FALSE
        m <- paste0("Pregunta ", toString(i))
    }
    
    # if (input[[id]] == "SI" & input[[id_date]] == Sys.Date()) {
    #     v <- FALSE
    #     m <- paste0("Fecha de la pregunta ", toString(i))
    # }
    
    return(list("v" = v, "m" = m))
}

preguntas_contestadas <- function(input) {
    val <- TRUE
    preguntas_sin_responder <- c()
    
    for (i in 1:1) {
        r <- val_pregunta(input, i)
        if (r$v == FALSE) {
            val <- FALSE
            preguntas_sin_responder <- c(preguntas_sin_responder, r$m)
        }
    }
    
    respuesta <- list("validacion" = val, "preguntas_v" = paste(preguntas_sin_responder, collapse = '\n'))
    return(respuesta)
}

deshabilitar_campos_pt <- function() {
    for (i in 1:28) {
        id <- paste("P",toString(i),"_PT",sep="")
        id_date <- paste("P",toString(i),"_PT_date",sep="")
        shinyjs::disable(id)
        shinyjs::disable(id_date)
    }
}


### ------------------
pruebas_tamizaje_functions <- function(input, output, session) {
    ############## DESHABILITAR FECHA
    hab_des_fecha <- function(i) {
        id <- paste("P",toString(i),"_PT",sep="")
        id_date <- paste("P",toString(i),"_PT_date",sep="")
        observeEvent(input[[id]],{
            if(input[[id]]=="SI"){
                shinyjs::enable(id_date)
            }else{
                shinyjs::disable(id_date)
                updateDateInput(session, id_date, value = Sys.Date())
            }
        })
    }
    for (i in 1:28) {
        hab_des_fecha(i)
    }


    observeEvent(input$PT, {

        respuesta <- preguntas_contestadas(input)
        print(respuesta)
        

        ############## SI ESTAN COMPLETOS LOS DATOS
        if (respuesta$validacion == TRUE) {

            ############## DESHABILITAR LAS PREGUNTAS
            deshabilitar_campos_pt()

            ############## HABILITAR LAS ESCALAS OBLIGATORIAS
            output$recOpt2 <- renderMenu({
                menuItem("Escalas obligatorias",
                    tabName = "menu_2",
                    menuSubItem("Mini Mental State", tabName = "sub1_1"),
                    menuSubItem("Escala de Barthel", tabName = "sub1_2"),
                    menuSubItem("Lawton Brody", tabName = "sub1_3"),
                    menuSubItem("Linda Fried", tabName = "sub1_4"),
                    menuSubItem("Mini Nutritional Assesment MNA", tabName = "sub1_5"),
                    menuSubItem("Valoraci\u00F3n Framingham", tabName = "sub1_6"),
                    menuSubItem("Findrisk", tabName = "sub1_7"),
                    menuSubItem("RiesgoAMR B", tabName = "sub1_8"),
                    menuSubItem("APGAR Familiar", tabName = "sub1_9")
                )
            })


            ############## HABILITAR ESCALAS ADICIONALES
            output$recOpt3 <- renderMenu({
                menuItem("Escalas adicionales",
                    tabName = "menu_3",
                    menuSubItem("Puma Score", tabName = "sub2_1"),
                    menuSubItem("RiesgoTromboembolico/ACV", tabName = "sub2_2"),
                    menuSubItem("Hasbles", tabName = "sub2_3")
                )
            })

            ############## HABILITAR RESULTADOS
            output$recOpt4 <- renderMenu({
                menuItem("Resultados", tabName = "menu_4")
            })

            ## Pop-UP registo correcto, seleccionar siguiente tabitem, Arriba pantalla
            shinyjs::alert("Preguntas completas")
            shinyjs::click("menu_2")
            updateTabItems(session, inputId = "sbmenu", selected = "sub1_1")
            shinyjs::runjs("window.scrollTo(0, 0)")


            ############## NO ESTAN COMPLETOS LO DATOS
        } else {
            message <- paste("Complete los siguientes campos:\n", respuesta$preguntas_v, sep="")
            shinyjs::alert(message)
        }
    })
}