apgar_familiar_functions <- function(input, output, session) {
    observeEvent(input$GApgar, {
        if (input$AP_P1 != 0 & input$AP_P2 != 0 & input$AP_P3 != 0 & input$AP_P4 != 0 & input$AP_P5 != 0 & input$AP_P6 != 0 & input$AP_P7 != 0 &
            input$AP_P8 != 0 & input$AP_P9 != 0 & input$AP_P10 != 0) {
            shinyjs::disable("AP_P1")
            shinyjs::disable("AP_P2")
            shinyjs::disable("AP_P3")
            shinyjs::disable("AP_P4")
            shinyjs::disable("AP_P5")
            shinyjs::disable("AP_P6")
            shinyjs::disable("AP_P7")
            shinyjs::disable("AP_P8")
            shinyjs::disable("AP_P9")
            shinyjs::disable("AP_P10")


            TotalAP <- (as.integer(input$AP_P1) + as.integer(input$AP_P2) + as.integer(input$AP_P3) + as.integer(input$AP_P4) + as.integer(input$AP_P5) +
                as.integer(input$AP_P6) + as.integer(input$AP_P7) + as.integer(input$AP_P8) + as.integer(input$AP_P9) + as.integer(input$AP_P10)) - 10


            if (TotalAP >= 18) {
                output$Resultado_AP <- renderText(paste("Resultado:", TotalAP, "ALTA SATISFACCION: BUENA FUNCION FAMILIAR"))
                output$Resultado_AP_F <- renderText(paste("Continuar seguimiento"))
            }

            if (TotalAP <= 17 & TotalAP >= 14) {
                output$Resultado_AP <- renderText(paste("Resultado:", TotalAP, "MEDIANA SATISFACCION: DISFUNSION LEVE"))
                output$Resultado_AP_F <- renderText(paste("Remitir psicologia y/o trabajo social"))
            }

            if (TotalAP <= 13 & TotalAP >= 10) {
                output$Resultado_AP <- renderText(paste("Resultado:", TotalAP, "BAJA SATISFACCION: DISFUNCION MODERADA"))
                output$Resultado_AP_F <- renderText(paste("Remitir psicologia y/o trabajo social"))
            }

            if (TotalAP <= 9) {
                output$Resultado_AP <- renderText(paste("Resultado:", TotalAP, "BAJA SATISFACCION: DISFUNSION SEVERA"))
                output$Resultado_AP_F <- renderText(paste("Remitir psicologia y/o trabajo social"))
            }
        } else {
            shinyjs::alert("Complete todas las preguntas")
        }
    })
}