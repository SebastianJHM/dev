findrisk_functions <- function(input, output, session) {
    ### SI TIENE CUIDADOR
    observeEvent(input$Genero, {
        if (input$Genero == "Femenino") {
            updateSelectInput(session, "FIND_P2", choices = list(
                "-" = 0,
                "Menos de 80 cms" = 1,
                "80 hasta 88 cms" = 2,
                "M\u00E1s 88 cms" = 3,
                "No se realiza" = 4
            ))
        }
    })
}