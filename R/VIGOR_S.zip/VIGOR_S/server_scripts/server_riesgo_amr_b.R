riesgo_amr_b_functions <- function(input, output, session) {
  ### SI Se puede medir el colestreol sanguineo
  
  observeEvent(input$AMRB_P1, {
    if (input$AMRB_P1 == 0) {
      shinyjs::enable("AMRB_P1.1")
    } else {
      updateSelectInput(session, "AMRB_P1.1", selected = 0)
      # updateSelectInput(session,"AMRB_P1.1",value = 0)
      shinyjs::disable("AMRB_P1.1")
    }
  })
}