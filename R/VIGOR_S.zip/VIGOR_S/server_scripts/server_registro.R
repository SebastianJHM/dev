verificacion_campos <- function(input) {

    val <- TRUE
    campos_vacios <- c()

    if (input$TipoID == 0) {
        val <- FALSE
        campos_vacios <- c(campos_vacios, "Tipo Identificaci\u00F3n")
    }
    # if (is.na(input$ID)) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Identificaci\u00F3n")
    # }
    # if (input$date == Sys.Date()) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Fecha de Nacimiento")
    # }
    # if (input$Genero == 0) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "G\u00E9nero")
    # }
    # if (input$FName == "") {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Primer Nombre")
    # }
    # if (input$SName == "") {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Segundo Nombre")
    # }
    # if (input$FLName == "") {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Primer Apellido")
    # }
    # if (input$SLName == "") {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Segundo Apellido")
    # }
    # if (is.na(input$TEL)) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Tel\u00E9fono")
    # }
    # if (is.na(input$Cel)) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Celular")
    # }
    # if (input$Direccion == "") {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Direcci\u00F3n")
    # }
    # if (input$Ciudad == "") {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Ciudad")
    # }
    # if (input$Departamento == "") {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Departamento")
    # }
    # if (input$EPS == "") {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "EPS del paciente")
    # }
    # if (input$Regimen == 0) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Regimen de afiliaci\u00F3n")
    # }
    # if (input$Cuidador == 0) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Cuidador")
    # }
    # if (input$Cuidador == 1 & input$NCuidador == "") {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Nombre Cuidador")
    # }
    # if (input$Cuidador == 1 & is.na(input$TCuidador)) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Tel\u00E9fono cuidador")
    # }
    # if (input$GEtnico == 0) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Grupo \u00E9tnico")
    # }
    # if (input$GEtnico == 1 & input$NGEtnico == "") {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "\u00BFCu\u00E1l grupo \u00E9tnico?")
    # }
    # if (input$NEscolaridad == 0) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Nivel de escolaridad")
    # }
    # if (input$TDiscapacidad == 0) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "\u00BFEl paciente presenta alg\u00FAn tipo de discapacidad\u003F")
    # }
    # if (input$TDiscapacidad == 1 & is.null(input$Discapacidad)) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Especif\u00EDque las discapacidades")
    # }
    # if (input$GEspecial == 0) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Pertenece a un grupo especial")
    # }
    # if (input$EMedico  == 0) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Especialidad M\u00E9dica")
    # }
    # if (input$Programa  == 0) {
    #     val <- FALSE
    #     campos_vacios <- c(campos_vacios, "Programa")
    # }

    respuesta <- list("validacion" = val, "campos_v" = paste(campos_vacios, collapse = '\n'))
    return(respuesta)
}

deshabilitar_campos_r <- function() {
    campos <- c("TipoID", "ID", "date", "Genero", "FName", "SName", "FLName", "SLName", "TEL", "Cel", 
    "Direccion", "Ciudad", "Departamento", "EPS", "Regimen", "Cuidador", "NCuidador", "TCuidador", 
    "GEtnico", "NGEtnico", "NEscolaridad", "TDiscapacidad", "Discapacidad", "GEspecial", "EMedico", 
    "Programa")

    for (campo in campos) {
        shinyjs::disable(campo)
    }
}


### -------------
registro_pacientes_functions <- function(input, output, session) {
    ### SI TIENE CUIDADOR
    observeEvent(input$Cuidador, {
        if (input$Cuidador == 1) {
            shinyjs::enable("NCuidador")
            shinyjs::enable("TCuidador")
            updateTextInput(session, "NCuidador", value = "")
            updateTextInput(session, "TCuidador", value = NA)
        } else {
            updateTextInput(session, "NCuidador", value = "")
            updateTextInput(session, "TCuidador", value = NA)
            shinyjs::disable("NCuidador")
            shinyjs::disable("TCuidador")
        }
    })

    ### SI TIENE ALGUNA DISCAPACIDAD
    observeEvent(input$TDiscapacidad, {
        if (input$TDiscapacidad == 1) {
            shinyjs::enable("Discapacidad")
            updateCheckboxGroupInput(session, "Discapacidad", selected = NULL, choiceValues = NULL)
        } else {
            updateCheckboxGroupInput(session, "Discapacidad", selected = 0)
            shinyjs::disable("Discapacidad")
        }
    })

    ### SI PERTENECE A UN GRUPO ETNICO
    observeEvent(input$GEtnico, {
        if (input$GEtnico == 1) {
            shinyjs::enable("NGEtnico")
            updateTextInput(session, "NGEtnico", value = "")
        } else {
            shinyjs::disable("NGEtnico")
            updateTextInput(session, "NGEtnico", value = "NA")
        }
    })

    ### VERIFICAR DATOS COMPLETOS
    observeEvent(input$action, {

        respuesta <- verificacion_campos(input)

        if (respuesta$validacion == TRUE) {

            ##" Deshabilitar campos"
            deshabilitar_campos_r()

            #### GUARDAR DATOS INICIALES
            BASE2 <- BASE %>% filter(TipoID == 8)
            BASE2[1, "TipoID"] <- input$TipoID
            BASE2[1, "ID"] <- input$ID
            BASE2[1, "date"] <- input$date
            BASE2[1, "Genero"] <- input$Genero

            BASE$date <- as.numeric(BASE$date)
            BASE$date <- as.Date(BASE$date, origin = "1970-01-01")



            ## HABILITAR TAB-TAMIZAJE
            output$recOpt <- renderMenu({
                menuItem("Pruebas de tamizaje", tabName = "menu_1")
            })

            ## Pop-UP registo correcto, seleccionar siguiente tabitem, Arriba pantalla
            shinyjs::alert("Registro Correcto")
            updateTabItems(session, inputId = "sbmenu", selected = "menu_1")
            shinyjs::runjs("window.scrollTo(0, 0)")
        } else {
            message <- paste("Complete los siguientes campos:\n", respuesta$campos_v, sep="")
            shinyjs::alert(message)
        }
    })
}