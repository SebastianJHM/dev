puma_score_functions <- function(input, output, session) {
    ### SI NO FUMA
    observeEvent(input$PUMAS_P1, {
        if (input$PUMAS_P1 == 1) {
            updateSliderInput(session, "PUMAS_P1.1", value = 0)
            shinyjs::disable("PUMAS_P1.1")

            updateSliderInput(session, "PUMAS_P1.2", value = 0)
            shinyjs::disable("PUMAS_P1.2")
        } else {
            shinyjs::enable("PUMAS_P1.1")
            shinyjs::enable("PUMAS_P1.2")
        }
    })
}