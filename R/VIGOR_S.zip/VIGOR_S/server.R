source(file = "server_scripts/server_registro.R")
source(file = "server_scripts/server_pruebas_tamizaje.R")
source(file = "server_scripts/server_mini_mental_state.R")
source(file = "server_scripts/server_findrisk.R")
source(file = "server_scripts/server_riesgo_amr_b.R")
source(file = "server_scripts/server_apgar_familiar.R")
source(file = "server_scripts/server_puma_score.R")
source(file = "server_scripts/server_resultados.R")

server <- function(input, output, session) {

    ################################################ REGISTRAR PACIENTE ########################################################################################
    registro_pacientes_functions(input, output, session)

    ################################################ PRUEBAS DE TAMIZAJE ########################################################################################
    pruebas_tamizaje_functions(input, output, session)

    ##################### Escalas obligatorias #####################
    ### 1. Mini Mental State ###
    mini_mental_state_functions(input, output, session)

    ### 2. Escala de Barthel ###


    ### 3. Escala de Lawton Brody ###


    ### 4. Escala de Linda Fried ###


    ### 5. MINI NUTRITIONAL ASSESSMENT  MNA ###


    ### 6. ValoraciOn Framingham ###

    ### 7. Findrisk ###
    findrisk_functions(input, output, session)

    ### 8. RiesgoAMR B ###
    riesgo_amr_b_functions(input, output, session)

    ### 9. APGAR Familiar ###
    apgar_familiar_functions(input, output, session)



    ##################### Escalas adicionales #####################
    ### 1. Puma Score ###
    puma_score_functions(input, output, session)

    #### 2. RiesgoTromboembolico/ACV ###


    ### 3. Hasbles ###


    ###################### Resultados ######################
    resultados_functions(input, output, session)
}